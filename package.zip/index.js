var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// src/styles.css
var require_styles = __commonJS({
  "src/styles.css"(exports2, module2) {
    module2.exports = `/* Only the outer chrome is hidden. Sidebar business panels are never removed. */\r
body.sim-active:not(.sim-window-strip) #toolbar:not(.sim-native-tools),\r
body.sim-active #dockLeft,\r
body.sim-active #dockRight,\r
body.sim-active #dockBottom,\r
body.sim-active #status,\r
body.sim-active .layout__center [data-type="wnd"] > .fn__flex:has(> .layout-tab-bar),\r
body.sim-active .layout__center .protyle-breadcrumb:not(.sim-page-tools) {\r
  display: none !important;\r
}\r
/* Inset the entire workspace so rounded panels have room around the edges.\r
   Fixed floating docks do not inherit body padding, so give them the same inset. */\r
body.sim-active { --b3-toolbar-height: 0px; --sim-edge-gap: 8px; --sim-topbar-height: 0px; padding: calc(var(--sim-edge-gap) + var(--sim-topbar-height)) var(--sim-edge-gap) var(--sim-edge-gap) !important; box-sizing: border-box; }\r
/* Keep the existing empty top inset draggable without covering any panel. */\r
.sim-window-drag {\r
  position: fixed; inset: 0 0 auto 0; height: var(--sim-edge-gap, 8px);\r
  z-index: 19; background: transparent; user-select: none; cursor: move; -webkit-app-region: drag;\r
}\r
.sim-window-drag::after {\r
  content: attr(title); position: absolute; left: 50%; top: 10px; transform: translate(-50%, -2px);\r
  padding: 4px 8px; border-radius: 5px; color: #fff; background: rgba(35, 39, 38, .84);\r
  font: 11px/1.2 var(--b3-font-family, system-ui); white-space: nowrap; opacity: 0;\r
  pointer-events: none; transition: opacity .12s, transform .12s;\r
}\r
.sim-window-drag:hover::after { opacity: .9; transform: translate(-50%, 0); }\r
body.sim-keep-topbar .sim-window-drag::after { display: none; }\r
body.sim-keep-topbar .sim-window-drag { display: none; }\r
/* Windows tool/tab content and native window controls are opt-in.\r
   No mouse-edge trigger, duplicate controls or Electron bridge is needed. */\r
/* Split the workspace's extra top gap equally above and below the chrome. */\r
body.sim-active.sim-window-strip { --sim-topbar-height: 28px; --sim-topbar-offset: calc(var(--sim-edge-gap) / 2); }\r
body.sim-active.sim-window-strip #toolbar {\r
  display: flex !important; position: fixed !important; inset: var(--sim-topbar-offset) 0 auto 0 !important;\r
  align-items: center !important; padding-top: 0 !important; padding-bottom: 0 !important;\r
  width: 100% !important; height: var(--sim-topbar-height) !important;\r
  transform: none !important; opacity: 1 !important; visibility: visible !important;\r
  min-height: 0 !important; line-height: var(--sim-topbar-height) !important;\r
  z-index: 20; background: transparent !important; border: 0 !important; box-shadow: none !important;\r
  -webkit-app-region: drag !important;\r
}\r
/* The whole chrome is draggable; only interactive controls subtract no-drag.\r
   Containers and spacers must not mask otherwise empty parts of the titlebar. */\r
body.sim-active.sim-window-strip #toolbar #drag {\r
  display: block !important; flex: 1 1 auto !important; min-width: 64px !important;\r
  height: var(--sim-topbar-height) !important; align-self: stretch !important;\r
  -webkit-app-region: drag !important;\r
}\r
body.sim-active.sim-window-strip #toolbar #drag::before,\r
body.sim-active.sim-window-strip #toolbar #drag::after { display: none !important; content: none !important; }\r
body.sim-active.sim-window-strip #toolbar #windowControls { align-items: center !important; -webkit-app-region: drag !important; }\r
body.sim-active.sim-keep-topbar #toolbar .sim-topbar-overflow { display: none !important; }\r
body.sim-active.sim-window-strip #toolbar :is(button, input, select, textarea, a, label, summary, [role="button"], [role="tab"], [contenteditable="true"], [tabindex]:not([tabindex="-1"]), [onclick], [data-menu="true"], .toolbar__item, .block__icon) { -webkit-app-region: no-drag !important; }\r
body.sim-active.sim-window-strip #toolbar :is(.toolbar__item--win, .toolbar__item--close) {\r
  height: 28px !important; padding-top: 6.25px !important; padding-bottom: 6.25px !important;\r
  box-sizing: border-box !important;\r
}\r
/* Position the existing tab rows over #drag, without reparenting them or\r
   reserving a second line inside the document. JS measures the available slot. */\r
body.sim-active.sim-keep-topbar .layout__center [data-type="wnd"] > .sim-merged-tabs:not(.fn__none):not([hidden]) {\r
  display: flex !important; visibility: visible !important; position: fixed !important;\r
  left: var(--sim-tabs-left) !important; top: var(--sim-topbar-offset) !important; right: auto !important; bottom: auto !important;\r
  width: var(--sim-tabs-width) !important; height: var(--sim-topbar-height) !important; min-width: 0 !important;\r
  padding: 0 !important; margin: 0 !important; box-sizing: border-box !important;\r
  z-index: 21; overflow: hidden; background: transparent !important;\r
  -webkit-app-region: drag !important;\r
}\r
body.sim-active.sim-keep-topbar .sim-merged-tabs > .layout-tab-bar {\r
  height: var(--sim-topbar-height) !important; min-height: 0 !important; margin: 0 !important; padding: 0 !important;\r
  background: transparent !important; border-bottom: 0 !important; box-sizing: border-box;\r
  overflow-x: auto; overflow-y: hidden; align-items: center;\r
  -webkit-app-region: drag !important;\r
}\r
body.sim-active.sim-keep-topbar .sim-merged-tabs > .layout-tab-bar:not(.layout-tab-bar--readonly) { flex: 1 1 0; min-width: 0 !important; }\r
body.sim-active.sim-keep-topbar .sim-merged-tabs > .layout-tab-bar--readonly { flex: 0 0 auto !important; min-width: 0 !important; }\r
body.sim-active.sim-keep-topbar .sim-merged-tabs .item--readonly { gap: 0 !important; }\r
body.sim-active.sim-keep-topbar .sim-merged-tabs .item--readonly,\r
body.sim-active.sim-keep-topbar .sim-merged-tabs .item--readonly > .fn__flex-1 { -webkit-app-region: drag !important; }\r
body.sim-active.sim-keep-topbar .sim-merged-tabs > .layout-tab-bar > .item {\r
  margin: 2px 4px !important; height: 24px !important; min-height: 0 !important; max-height: 24px !important;\r
  padding-top: 0 !important; padding-bottom: 0 !important; line-height: 22px !important;\r
}\r
body.sim-active.sim-keep-topbar .sim-merged-tabs > .layout-tab-bar > .item:first-child { margin-left: 0 !important; }\r
body.sim-active.sim-keep-topbar .sim-merged-tabs > .layout-tab-bar::-webkit-scrollbar { display: none; }\r
body.sim-active.sim-keep-topbar .sim-merged-tabs > .layout-tab-bar:not(.layout-tab-bar--readonly) > [data-id],\r
body.sim-active.sim-keep-topbar .sim-merged-tabs :is(button, input, select, textarea, a, label, summary, [role="button"], [role="tab"], [contenteditable="true"], [tabindex]:not([tabindex="-1"]), [onclick], [data-menu="true"], .block__icon) { -webkit-app-region: no-drag !important; }\r
body.sim-active.sim-keep-topbar .sim-merged-tabs .layout-tab-bar--readonly [data-type="more"].sim-tab-switch-hidden { display: none !important; }\r
body.sim-active > .layout { margin-top: 0 !important; padding-top: 0 !important; }\r
body.sim-active .sim-layout-row { margin-left: 0 !important; margin-right: 0 !important; margin-bottom: 0 !important; }\r
body.sim-active .layout__dockl,\r
body.sim-active .layout__dockr { margin-top: 0 !important; }\r
/* One continuous, theme-colored outline on all four sides of each panel.\r
   Do not keep a second outline around the center's wrapper / split panes. */\r
body.sim-active .layout__center { border: 0 !important; box-shadow: none !important; }\r
body.sim-active .layout__dockl,\r
body.sim-active .layout__dockr,\r
body.sim-active .layout__dockb,
body.sim-active .layout__center [data-type="wnd"] > .layout-tab-container {
  border: 1px solid var(--b3-border-color, var(--b3-theme-surface-lighter, #ddd)) !important;
  border-radius: var(--b3-border-radius-b, 12px) !important;
  box-sizing: border-box !important;
}
body.sim-active .layout__dockl.layout--float,\r
body.sim-active .layout__dockr.layout--float {\r
  top: calc(var(--sim-edge-gap) + var(--sim-topbar-height)) !important; bottom: var(--sim-edge-gap) !important;\r
  height: auto !important; max-height: none !important;\r
  border-radius: var(--b3-border-radius-b, 12px) !important;\r
}\r
body.sim-active .layout__dockl.layout--float { left: var(--sim-edge-gap) !important; }\r
body.sim-active .layout__dockr.layout--float { right: var(--sim-edge-gap) !important; }\r
body.sim-active .layout__dockb.layout--float {
  left: var(--sim-edge-gap) !important; right: var(--sim-edge-gap) !important; bottom: var(--sim-edge-gap) !important;
  max-height: none !important; border-radius: var(--b3-border-radius-b, 12px) !important;
}
/* SiYuan keeps collapsed Dock shells in layout with a zero inline size. They
   must not receive the shared panel outline, otherwise a lone 1px gray line
   remains at the right/bottom edge. */
body.sim-active :is(.layout__dockl, .layout__dockr)[style*="width: 0px"],
body.sim-active :is(.layout__dockl, .layout__dockr)[style*="width:0px"],
body.sim-active .layout__dockb[style*="height: 0px"],
body.sim-active .layout__dockb[style*="height:0px"] {
  border: 0 !important;
  box-shadow: none !important;
}
body.sim-active #toolbar.sim-native-tools {
  display: flex !important; position: fixed !important; inset: 0 0 auto 0 !important;\r
  height: 42px !important; z-index: 20; background: var(--b3-theme-background, #fff);\r
  box-shadow: 0 4px 16px #0002;\r
}\r
/* A revealed page toolbar keeps the host's native document-flow layout and\r
   theme. Immersive mode only opts it out of the hidden-breadcrumb selector. */\r
.sim-orb, .sim-menu { box-sizing: border-box; color: var(--b3-theme-on-background, #27312f); font-family: var(--b3-font-family, system-ui); }\r
/* Compact AssistiveTouch-inspired white disc, neutral rings and translucent shell.
   Activation changes contrast without changing the button footprint. */
.sim-orb {
  position: fixed; width: 32px; height: 32px; padding: 0; border: 1px solid #ffffff38;
  border-radius: 11px; background: rgba(45, 47, 52, .48);
  box-shadow: 0 2px 8px #0002; opacity: .55;
  -webkit-backdrop-filter: blur(12px); backdrop-filter: blur(12px);\r
  z-index: 25; cursor: grab; touch-action: none; user-select: none; -webkit-app-region: no-drag;\r
  display: grid; place-items: center; transition: opacity .2s, background .2s, box-shadow .2s;\r
}\r
.sim-orb::before {
  content: ""; width: 16px; height: 16px; border-radius: 50%;
  background: linear-gradient(#fff, #f1f1f3); border: 1px solid #fff;\r
  box-shadow: 0 0 0 3px #ffffff30, 0 0 0 6px #ffffff12, 0 1px 4px #0003;\r
  pointer-events: none; transition: transform .2s, box-shadow .2s;\r
}\r
.sim-orb:hover, .sim-orb:focus-visible { opacity: .9; }\r
.sim-orb--active { opacity: 1; background: rgba(45, 47, 52, .68); box-shadow: 0 3px 11px #0003; }
.sim-orb--active::before { transform: scale(1.06); box-shadow: 0 0 0 3px #ffffff55, 0 0 0 6px #ffffff20, 0 1px 4px #0003; }\r
.sim-orb:active { cursor: grabbing; }\r
.sim-menu {
  --sim-menu-hover: var(--b3-list-hover, #eeeeee);\r
  position: fixed; width: min(280px, calc(100vw - 16px)); max-height: min(480px, calc(100vh - 16px));\r
  display: flex; flex-direction: column; border: 1px solid var(--b3-border-color, #ddd);\r
  border-radius: 10px; background: var(--b3-theme-background, #fff); box-shadow: 0 8px 24px #0002;\r
  z-index: 26; overflow: hidden; -webkit-app-region: no-drag; font: 11.5px/16px var(--b3-font-family, system-ui);\r
  animation: sim-card-in .18s ease-out;
}
.sim-menu-header { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 11px 12px 4px 19px; flex-shrink: 0; }
.sim-menu-header strong { font-size: 13px; line-height: 18px; font-weight: 600; }
.sim-window-button.sim-header-exit, .sim-window-actions [data-control-key="exit"] { color: var(--b3-theme-primary, #4c7cf3); }
.sim-menu-tabs { padding: 0 0 4px; }\r
.sim-menu-tabs h3 { flex-shrink: 0; margin-top: 6px; }\r
.sim-tab-list { overflow: visible; }\r
.sim-tab-row { display: flex; align-items: center; min-width: 0; border-radius: 5px; }
.sim-tab-row:hover, .sim-tab-row:focus-within, .sim-tab-row--active { background: var(--sim-menu-hover); }
.sim-menu .sim-tab { box-sizing: border-box; display: flex; align-items: center; gap: 6px; flex: 1 1 auto; min-width: 0; min-height: 26px; padding: 5px 7px; text-align: left; }
.sim-tab-marker { flex-shrink: 0; font-size: 9px; opacity: .6; }\r
.sim-tab-label { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }\r
.sim-menu .sim-tab[aria-current="true"] { background: transparent; font-weight: 500; }
.sim-window-button.sim-tab-close { opacity: 0; margin-right: 2px; color: #d84c4c; transition: opacity .12s ease-out, background-color .12s ease-out; }
.sim-tab-row:hover .sim-tab-close, .sim-tab-row:focus-within .sim-tab-close { opacity: .68; }
.sim-tab-row .sim-tab-close:hover, .sim-tab-row .sim-tab-close:focus-visible { opacity: 1; background: color-mix(in srgb, #d84c4c 12%, transparent); }
.sim-menu .sim-tabs-toggle { flex-shrink: 0; padding: 5px 7px; text-align: left; font-size: 11.5px; color: var(--b3-theme-on-surface, #777); }\r
.sim-menu-other-scroll { flex: 1 1 auto; overflow-y: auto; overscroll-behavior: contain; padding: 0 12px 4px; min-height: 0; }\r
.sim-menu h3 { margin: 9px 7px 4px; font-size: 11.5px; font-weight: 500; color: var(--b3-theme-on-surface, #777); }\r
.sim-menu h3 small { margin-left: 6px; font-size: 10px; opacity: .75; }\r
.sim-action-group { padding-bottom: 4px; }\r
.sim-action-group + .sim-action-group, .sim-menu-tabs + .sim-action-group { border-top: 1px solid var(--b3-border-color, #eee); margin-top: 3px; }\r
.sim-empty { margin: 10px 8px; color: var(--b3-theme-on-surface, #777); font-size: 12px; }\r
.sim-row { display: flex; min-width: 0; align-items: center; gap: 3px; border-radius: 5px; }\r
.sim-row:hover, .sim-row--active, .sim-row--activefocus { background: var(--sim-menu-hover); }\r
.sim-row:hover { cursor: pointer; }\r
.sim-menu button { font: inherit; color: inherit; border: 0; background: transparent; cursor: pointer; border-radius: 5px; }\r
.sim-action { box-sizing: border-box; display: flex; align-items: center; gap: 6px; flex: 1; min-width: 0; width: 100%; text-align: left; padding: 5px 7px; min-height: 26px; }\r
.sim-menu .sim-action, .sim-menu .sim-action:hover { background: transparent !important; }\r
.sim-action-label { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }\r
.sim-action svg { width: 14px; height: 14px; fill: currentColor; flex-shrink: 0; }\r
.sim-submenu-chevron { margin-left: auto; flex: 0 0 auto; font-size: 15px; line-height: 1; opacity: .6; }\r
.sim-plugin-settings { position: relative; margin-top: 7px; }
.sim-plugin-settings::before { content: ""; position: absolute; left: 0; right: 0; top: -4px; border-top: 1px solid var(--b3-border-color, #eee); pointer-events: none; }
.sim-window-actions {
  box-sizing: border-box; display: flex; align-items: center; justify-content: space-around; align-self: center; flex: 0 0 auto;
  gap: 4px; width: calc(100% - 24px); min-height: 34px; margin: 4px auto 8px; padding: 5px 10px;
  border: 1px solid var(--b3-border-color, #ddd); border-radius: 10px;
  background: color-mix(in srgb, var(--b3-theme-background, #fff) 92%, transparent);
  color: var(--b3-theme-on-background, #27312f); box-shadow: 0 3px 12px #0000001a;
  -webkit-backdrop-filter: blur(14px) saturate(135%); backdrop-filter: blur(14px) saturate(135%);
  -webkit-app-region: no-drag; animation: sim-dock-in .18s ease-out;
}
.sim-window-button { box-sizing: border-box; display: grid; place-items: center; padding: 4px; width: 22px; height: 22px; flex: 0 0 22px; border: 0; border-radius: 6px; background: transparent; color: inherit; cursor: pointer; -webkit-app-region: no-drag; }
.sim-window-button svg { width: 14px; height: 14px; fill: currentColor; pointer-events: none; }
.sim-window-button:hover:not(:disabled) { background: var(--b3-list-hover, #eeeeee); }\r
.sim-window-button:disabled { opacity: .4; cursor: default; }\r
.sim-window-button:focus-visible { outline: 2px solid var(--b3-theme-on-surface, #777); outline-offset: -2px; }\r
.sim-menu button:hover:not(.sim-action):not(.sim-tab):not(:disabled) { background: var(--sim-menu-hover); }
.sim-menu button:disabled { opacity: .4; cursor: default; }\r
.sim-menu button:focus-visible, .sim-orb:focus-visible { outline: 2px solid var(--b3-theme-on-surface, #777); outline-offset: -2px; }\r
/* The real SiYuan menu is the second card. Its children, parent, event handlers\r
   and deeper submenus remain owned by SiYuan. Only position and shell change. */\r
body.sim-active .b3-menu.sim-native-submenu {\r
  left: var(--sim-submenu-left) !important; top: var(--sim-submenu-top) !important;\r
  -webkit-app-region: no-drag;\r
}\r
body.sim-active .b3-menu.sim-native-submenu,\r
body.sim-active .sim-native-submenu .b3-menu__submenu {\r
  box-sizing: border-box; width: min(230px, calc(100vw - 32px)) !important; min-width: 0 !important;\r
  max-width: calc(100vw - 32px) !important; padding: 5px !important;\r
  border: 1px solid var(--b3-border-color, #ddd); border-radius: 10px !important;\r
  background: var(--b3-theme-background, #fff); color: var(--b3-theme-on-background, #333);\r
  box-shadow: 0 8px 24px #0002; font: 11.5px/16px var(--b3-font-family, system-ui);\r
}\r
body.sim-active .sim-native-submenu > .b3-menu__items {\r
  /* Measure the full usable height before placement. A limit based on the old\r
     top position shrinks the menu before it can move upward near the bottom. */\r
  max-height: min(340px, calc(100vh - 28px)) !important; overflow-y: auto;\r
}\r
body.sim-active .sim-native-submenu .b3-menu__submenu { max-height: min(352px, calc(100vh - 16px)); overflow-y: auto; }\r
body.sim-active .sim-native-submenu .sim-child-positioned { top: var(--sim-child-top) !important; }\r
body.sim-active .sim-native-submenu .b3-menu__item { box-sizing: border-box; min-height: 26px; padding: 5px 7px !important; gap: 6px; border-radius: 5px; font: 11.5px/16px var(--b3-font-family, system-ui) !important; }\r
body.sim-active .sim-native-submenu .b3-menu__item :is(.b3-menu__label, span, small) { font-size: 11.5px !important; line-height: 16px !important; }\r
body.sim-active .sim-native-submenu .b3-menu__item svg { width: 14px; height: 14px; flex-shrink: 0; }\r
body.sim-active .sim-native-submenu .b3-menu__item:hover:not(:disabled) { background: var(--b3-list-hover, #eeeeee); }\r
body.sim-active .sim-native-submenu .b3-menu__accelerator { display: none !important; }\r
.sim-sync-tip { position: fixed; z-index: 27; box-sizing: border-box; max-width: min(240px, calc(100vw - 16px)); max-height: calc(100vh - 16px); padding: 7px 9px; border: 1px solid var(--b3-border-color, #ddd); border-radius: 7px; background: var(--b3-theme-background, #fff); color: var(--b3-theme-on-background, #333); box-shadow: 0 4px 16px #0002; font: 11px/1.5 var(--b3-font-family, system-ui); white-space: pre-wrap; overflow-wrap: anywhere; overflow: hidden; pointer-events: none; }\r
.sim-immersive-entry { color: var(--b3-theme-primary, #4c7cf3) !important; }
.sim-immersive-entry svg { fill: currentColor; }
.sim-orb[hidden], .sim-menu[hidden] { display: none !important; }\r
\r
@keyframes sim-card-in { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }
@keyframes sim-dock-in { from { opacity: 0; transform: translateY(3px) scale(.98); } to { opacity: 1; transform: translateY(0) scale(1); } }
@media (prefers-reduced-motion: reduce) { .sim-menu, .sim-window-actions { animation: none; } }
`;
  }
});

// src/ui.css
var require_ui = __commonJS({
  "src/ui.css"(exports2, module2) {
    module2.exports = `/* Available in ordinary mode too; scoped to this plugin's entry and dialog. */\r
.toolbar__item.sim-immersive-entry { display: flex; align-items: center; justify-content: center; line-height: 0; color: var(--b3-theme-primary, #4c7cf3) !important; }
.toolbar__item.sim-immersive-entry svg { display: block; width: 14px; height: 14px; margin: auto; color: var(--b3-theme-primary, #4c7cf3) !important; fill: currentColor !important; }
.toolbar__item.sim-immersive-entry svg path { fill: currentColor !important; }
/* SiYuan clones top-bar entries into the plugin menu and replaces their class
   with b3-menu__icon. Identify this plugin's stable frame path in that clone. */
.b3-menu__item:has(> svg.b3-menu__icon > path[d^="M950.857143 73.142857"]) > svg.b3-menu__icon {
  color: var(--b3-theme-primary, #4c7cf3) !important;
  fill: currentColor !important;
}
.b3-menu__item:has(> svg.b3-menu__icon > path[d^="M950.857143 73.142857"]) > svg.b3-menu__icon path { fill: currentColor !important; }
.sim-settings-dialog .b3-dialog__container { height: fit-content !important; min-height: 0; max-height: calc(100vh - 32px); }\r
.sim-settings-dialog .b3-dialog__body { min-height: 0; }\r
.sim-settings-dialog .b3-dialog__content { flex: 0 1 auto; padding: 14px 20px 16px; overflow-y: auto; }
.sim-settings-dialog .config-item { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 12px; align-items: start; padding: 12px 0; min-height: 0; }\r
.sim-settings-dialog .config-item > .fn__space { display: none; }\r
.sim-settings-dialog .config-item > .fn__flex-1 { min-width: 0; }\r
.sim-settings-dialog .config-name { line-height: 22px; }\r
.sim-settings-dialog .b3-label__text { margin-top: 4px; font-size: 12px; line-height: 18px; }\r
.sim-settings-dialog .config-item > input { align-self: start; margin-top: 2px; }\r
.sim-settings-dialog .config-item > input[type="number"] { width: 64px !important; }\r
.sim-settings-dialog .config-item:last-of-type { border-bottom: 0; }\r
.sim-settings-version { padding-top: 6px; text-align: left; font-size: 11px; line-height: 18px; color: var(--b3-theme-on-surface, #777); }
`;
  }
});

// plugin.json
var require_plugin = __commonJS({
  "plugin.json"(exports2, module2) {
    module2.exports = {
      name: "siyuan-plugin-immersive-mode",
      author: "chengslog",
      url: "https://github.com/chengslog/siyuan-plugin-immersive-mode",
      version: "1.0.0",
      minAppVersion: "3.1.24",
      backends: ["windows", "linux", "darwin", "docker"],
      frontends: ["desktop", "browser-desktop"],
      displayName: { default: "Immersive Mode", zh_CN: "Immersive \u6C89\u6D78\u6A21\u5F0F", "zh-CN": "Immersive \u6C89\u6D78\u6A21\u5F0F" },
      description: { default: "A minimal workspace with a floating tab and command card.", zh_CN: "\u72EC\u7ACB\u6C89\u6D78\u6A21\u5F0F\uFF1A\u60AC\u6D6E\u7403\u3001\u6298\u53E0\u9875\u7B7E\u4E0E\u539F\u751F\u4FA7\u680F\u3002", "zh-CN": "\u72EC\u7ACB\u6C89\u6D78\u6A21\u5F0F\uFF1A\u60AC\u6D6E\u7403\u3001\u6298\u53E0\u9875\u7B7E\u4E0E\u539F\u751F\u4FA7\u680F\u3002" },
      readme: { default: "README.md" },
      keywords: ["immersive", "\u6C89\u6D78", "\u60AC\u6D6E\u7403"]
    };
  }
});

// src/core.js
var require_core = __commonJS({
  "src/core.js"(exports2, module2) {
    var DEFAULTS = { favorites: [], side: "right", y: 0.65, windowsTopBar: false, tabPreviewCount: 5, autoEnterOnResourceOpen: false };
    var ACTION_GROUPS2 = [
      ["left", "\u5DE6\u4FA7\u680F"],
      ["top", "\u4E0A\u4FA7\u680F"],
      ["right", "\u53F3\u4FA7\u680F"],
      ["bottom", "\u4E0B\u4FA7\u680F"],
      ["unknown-dock", "\u5176\u4ED6 Dock\uFF08\u4F4D\u7F6E\u672A\u8BC6\u522B\uFF09"]
    ];
    function normalizeSettings2(value) {
      const data = value && typeof value === "object" ? value : {};
      return {
        // Preserve legacy preferences on disk without rendering favorites or stars.
        favorites: Array.isArray(data.favorites) ? [...new Set(data.favorites.filter((x) => typeof x === "string"))] : [],
        side: data.side === "left" ? "left" : "right",
        y: Number.isFinite(data.y) ? Math.min(1, Math.max(0, data.y)) : DEFAULTS.y,
        windowsTopBar: data.windowsTopBar === true,
        autoEnterOnResourceOpen: data.autoEnterOnResourceOpen === true,
        tabPreviewCount: Number.isFinite(data.tabPreviewCount) ? clamp2(Math.floor(data.tabPreviewCount), 1, 20) : DEFAULTS.tabPreviewCount
      };
    }
    function clamp2(value, min, max) {
      return Math.max(min, Math.min(value, Math.max(min, max)));
    }
    function orbPosition2(settings, width, height) {
      return { x: settings.side === "left" ? 8 : Math.max(8, width - 40), y: clamp2(settings.y * (height - 32), 8, height - 40) };
    }
    function mergedTabSlots(left, right, weights) {
      if (!weights.length) return [];
      const start = Math.max(0, left) + 4;
      const available = Math.max(0, right - start - 48);
      const gap = Math.min(4, available / (weights.length * 2));
      const content = Math.max(0, available - gap * (weights.length - 1));
      const normalized = weights.map((value) => Number.isFinite(value) && value > 0 ? value : 1);
      const total = normalized.reduce((sum, value) => sum + value, 0);
      let x = start;
      return normalized.map((value) => {
        const width = content * value / total;
        const slot = { left: x, width };
        x += width + gap;
        return slot;
      });
    }
    function tabsOverflow2(scrollWidth, clientWidth, switcherWidth = 0) {
      return clientWidth > 0 && scrollWidth > clientWidth + Math.max(0, switcherWidth) + 1;
    }
    function plainLabel2(element) {
      const raw = element.getAttribute("data-title") || element.getAttribute("aria-label") || element.getAttribute("title") || element.textContent || "";
      const parser = element.ownerDocument.createElement("template");
      parser.innerHTML = raw;
      return (parser.content.textContent || "").replace(/\s+/g, " ").trim().slice(0, 100);
    }
    var NATIVE_TOOLBAR = {
      barPlugins: ["\u63D2\u4EF6\u7BA1\u7406", "iconPlugin"],
      barCommand: ["\u547D\u4EE4\u9762\u677F", "iconTerminal"],
      barSearch: ["\u5168\u5C40\u641C\u7D22", "iconSearch"],
      barSync: ["\u540C\u6B65", "iconCloudSucc"],
      barMode: ["\u5916\u89C2\u6A21\u5F0F", "iconMode"],
      barZoom: ["\u754C\u9762\u7F29\u653E", "iconZoomIn"],
      barMore: ["\u66F4\u591A\u4E0E\u8BBE\u7F6E", "iconMore"],
      barWorkspace: ["\u5DE5\u4F5C\u7A7A\u95F4\u4E0E\u4E3B\u83DC\u5355", "iconMenu"],
      barBack: ["\u540E\u9000", "iconLeft"],
      barForward: ["\u524D\u8FDB", "iconRight"]
    };
    var NATIVE_DOCK = {
      file: ["\u6587\u6863\u6811", "iconFiles"],
      outline: ["\u5927\u7EB2", "iconOutline"],
      inbox: ["\u6536\u96C6\u7BB1", "iconInbox"],
      bookmark: ["\u4E66\u7B7E", "iconBookmark"],
      tag: ["\u6807\u7B7E", "iconTag"],
      agentChat: ["\u667A\u80FD\u52A9\u624B", "iconSparkles"],
      graph: ["\u5173\u7CFB\u56FE", "iconGraph"],
      globalGraph: ["\u5168\u5C40\u5173\u7CFB\u56FE", "iconGlobalGraph"],
      backlink: ["\u53CD\u94FE", "iconLink"]
    };
    function dockGroup(element, registeredPosition) {
      if (element.closest("#dockBottom")) return "bottom";
      const rail = element.closest("#dockLeft, #dockRight");
      if (rail) {
        const slots = [...rail.children].filter((node) => node.classList.contains("dock__items"));
        if (slots.length >= 3 && slots[2].contains(element)) return "bottom";
        return rail.id === "dockLeft" ? "left" : "right";
      }
      const layout = element.ownerDocument.defaultView?.siyuan?.layout;
      const type = element.getAttribute("data-type");
      for (const [key, group] of [["bottomDock", "bottom"], ["leftDock", "left"], ["rightDock", "right"]]) {
        const dock = layout?.[key];
        if (Array.from(dock?.elements || []).some((slot) => slot?.contains(element))) return group;
      }
      for (const [key, group] of [["bottomDock", "bottom"], ["leftDock", "left"], ["rightDock", "right"]]) {
        if (Object.prototype.hasOwnProperty.call(layout?.[key]?.data || {}, type)) return group;
      }
      if (typeof registeredPosition === "string") {
        if (registeredPosition.startsWith("Bottom")) return "bottom";
        if (registeredPosition.startsWith("Left")) return "left";
        if (registeredPosition.startsWith("Right")) return "right";
      }
      return "unknown-dock";
    }
    function discoverActions2(doc, ownButton, plugins = [], positions = /* @__PURE__ */ new WeakMap()) {
      const result = [];
      const seen = /* @__PURE__ */ new Set();
      const pluginMetadata = /* @__PURE__ */ new Map();
      const dockMetadata = /* @__PURE__ */ new Map();
      for (const plugin of plugins || []) {
        if (!plugin) continue;
        for (const element of plugin.topBarIcons || []) {
          if (element?.nodeType === 1) pluginMetadata.set(element, { title: plugin.displayName || plugin.name });
        }
        for (const [type, definition] of Object.entries(plugin.docks || {})) {
          dockMetadata.set(type, { title: definition?.config?.title || plugin.displayName || plugin.name, icon: definition?.config?.icon, position: definition?.config?.position });
        }
      }
      const candidates = /* @__PURE__ */ new Set([
        ...doc.querySelectorAll('#toolbar .toolbar__item, .dock__item[data-type], [id^="plugin_"][data-menu="true"]'),
        ...Object.keys(NATIVE_TOOLBAR).map((id) => doc.getElementById(id)).filter(Boolean),
        ...pluginMetadata.keys()
      ]);
      for (const element of candidates) {
        if (!element.isConnected) continue;
        if (element === ownButton || element.closest("#windowControls") || element.id === "barExit") continue;
        if (element.matches('[hidden], [disabled], [aria-disabled="true"], .toolbar__item--disabled, .dock__item--disabled')) continue;
        if (element.classList.contains("fn__none") && element.id !== "barZoom") continue;
        const type = element.getAttribute("data-type");
        const isDock = element.classList.contains("dock__item");
        const key = isDock ? type && `dock:${type}` : element.id && `top:${element.id}`;
        const native = isDock ? NATIVE_DOCK[type] : NATIVE_TOOLBAR[element.id];
        const plugin = isDock ? dockMetadata.get(type) : pluginMetadata.get(element);
        const title = element.id === "barSync" ? "\u540C\u6B65" : stripShortcuts2(plainLabel2(element)) || native?.[0] || plugin?.title;
        if (!key || !title || seen.has(key)) continue;
        seen.add(key);
        const origin = native || !isDock && !plugin && !element.id.startsWith("plugin_") ? "\u539F\u751F" : "\u63D2\u4EF6";
        const group = isDock ? dockGroup(element, plugin?.position) : "top";
        const hasSubmenu = !isDock && (["barWorkspace", "barMore", "barPlugins", "barMode", "barZoom"].includes(element.id) || ["menu", "true"].includes(element.getAttribute("aria-haspopup") || ""));
        const mayOpenMenu = !isDock && (hasSubmenu || element.dataset.menu === "true" || !!plugin);
        const rect = element.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) positions.set(element, { group, left: rect.left, top: rect.top });
        result.push({ key, title, element, icon: native?.[1] || plugin?.icon, origin, group, hasSubmenu, mayOpenMenu });
      }
      return ACTION_GROUPS2.flatMap(([group]) => {
        const items = result.filter((action) => action.group === group);
        const axis = ["top", "bottom"].includes(group) ? "left" : "top";
        const measured = items.every((action) => positions.get(action.element)?.group === group);
        return items.sort((a, b) => {
          if (measured) {
            const delta = positions.get(a.element)[axis] - positions.get(b.element)[axis];
            if (Math.abs(delta) > 1) return delta;
          }
          const relation = a.element.compareDocumentPosition(b.element);
          return relation & 1 ? 0 : relation & 4 ? -1 : relation & 2 ? 1 : 0;
        });
      });
    }
    function stripShortcuts2(text) {
      return text.replace(/\s*[（(]?\s*(?:(?:Ctrl|Control|Alt|Shift|Meta|Cmd|Command|Option)\s*\+\s*)+[^\s()（）]+\s*[）)]?/gi, "").replace(/\s*[（(]?[⌘⌥⇧⌃]+[^\s()（）]*[）)]?/g, "").trim();
    }
    module2.exports = { DEFAULTS, ACTION_GROUPS: ACTION_GROUPS2, normalizeSettings: normalizeSettings2, clamp: clamp2, orbPosition: orbPosition2, plainLabel: plainLabel2, stripShortcuts: stripShortcuts2, discoverActions: discoverActions2, mergedTabSlots, tabsOverflow: tabsOverflow2 };
  }
});

// src/icons.js
var require_icons = __commonJS({
  "src/icons.js"(exports2, module2) {
    var frame = "M950.857143 73.142857c-21.942857-21.942857-58.514286-36.571429-95.085714-36.571428H168.228571C131.657143 29.257143 95.085714 43.885714 73.142857 73.142857s-43.885714 58.514286-43.885714 95.085714v687.542858c0 36.571429 14.628571 73.142857 36.571428 95.085714 21.942857 21.942857 58.514286 36.571429 95.085715 36.571428h687.542857c36.571429 0 73.142857-14.628571 95.085714-36.571428 21.942857-21.942857 36.571429-58.514286 36.571429-95.085714V168.228571c14.628571-36.571429 0-73.142857-29.257143-95.085714z m-29.257143 782.628572c0 36.571429-29.257143 65.828571-65.828571 65.828571H168.228571c-36.571429 0-65.828571-29.257143-65.828571-65.828571V168.228571c0-36.571429 29.257143-65.828571 65.828571-65.828571h687.542858c36.571429 0 65.828571 29.257143 65.828571 65.828571v687.542858z";
    var enter = "M775.314286 204.8H548.571429c-7.314286 0-7.314286 7.314286-14.628572 7.314286 0 0-7.314286 7.314286-7.314286 14.628571v29.257143c0 7.314286 7.314286 7.314286 7.314286 14.628571 0 0 7.314286 7.314286 14.628572 7.314286h160.914285L548.571429 438.857143s-7.314286 7.314286-7.314286 14.628571v29.257143c0 7.314286 7.314286 7.314286 7.314286 14.628572s7.314286 7.314286 14.628571 7.314285h29.257143c7.314286 0 7.314286-7.314286 14.628571-7.314285l146.285715-146.285715v124.342857c0 7.314286 7.314286 21.942857 7.314285 21.942858 7.314286 7.314286 14.628571 7.314286 21.942857 7.314285s21.942857-7.314286 21.942858-7.314285c7.314286-7.314286 7.314286-14.628571 7.314285-21.942858V248.685714c0-14.628571-7.314286-21.942857-14.628571-29.257143s-14.628571-14.628571-21.942857-14.628571zM460.8 746.057143H336.457143l146.285714-146.285714c7.314286 0 7.314286-14.628571 7.314286-21.942858 0-7.314286-7.314286-21.942857-7.314286-21.942857-7.314286-7.314286-14.628571-14.628571-29.257143-14.628571-7.314286 0-14.628571 7.314286-21.942857 14.628571L277.942857 709.485714v-146.285714-14.628571c0-7.314286-7.314286-7.314286-14.628571-14.628572 0 0-7.314286-7.314286-14.628572-7.314286H219.428571s0 7.314286-7.314285 7.314286c0 0-7.314286 7.314286-7.314286 14.628572v226.742857c0 21.942857 21.942857 43.885714 43.885714 43.885714h212.114286c7.314286 0 21.942857-7.314286 21.942857-7.314286 7.314286-7.314286 7.314286-14.628571 7.314286-21.942857 0-7.314286-7.314286-21.942857-7.314286-21.942857 0-14.628571-7.314286-21.942857-21.942857-21.942857z";
    var exit = "M811.885714 438.857143s-7.314286-7.314286-14.628571-7.314286H636.342857l160.914286-160.914286s7.314286-7.314286 7.314286-14.628571v-14.628571-14.628572c0-7.314286 0-7.314286-7.314286-14.628571 0 0-7.314286-7.314286-14.628572-7.314286h-29.257142c-7.314286 0-7.314286 7.314286-14.628572 7.314286l-146.285714 146.285714V241.371429c7.314286-7.314286 0-21.942857-7.314286-21.942858s-14.628571-14.628571-21.942857-14.628571-21.942857 7.314286-29.257143 14.628571c-7.314286 0-7.314286 14.628571-7.314286 21.942858v212.114285c0 14.628571 7.314286 21.942857 14.628572 29.257143s21.942857 14.628571 29.257143 14.628572h226.742857c7.314286 0 7.314286-7.314286 14.628571-7.314286 0 0 7.314286-7.314286 7.314286-14.628572v-14.628571-14.628571c-7.314286 0-7.314286-7.314286-7.314286-7.314286zM453.485714 526.628571H241.371429c-7.314286 0-21.942857 0-29.257143 7.314286-7.314286 7.314286-7.314286 14.628571-7.314286 29.257143 0 7.314286 7.314286 21.942857 7.314286 21.942857 7.314286 7.314286 21.942857 14.628571 29.257143 14.628572H365.714286l-146.285715 146.285714c-7.314286 7.314286-7.314286 14.628571-7.314285 21.942857s7.314286 21.942857 7.314285 21.942857c7.314286 7.314286 14.628571 14.628571 29.257143 14.628572 7.314286 0 21.942857-7.314286 21.942857-7.314286l153.6-153.6V804.571429c7.314286 0 7.314286 0 14.628572 7.314285 0 0 7.314286 7.314286 14.628571 7.314286h29.257143c7.314286 0 7.314286-7.314286 14.628572-7.314286 0 0 7.314286-7.314286 7.314285-14.628571V570.514286c-7.314286-21.942857-29.257143-43.885714-51.2-43.885715z";
    var svg = (path) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" aria-hidden="true" fill="currentColor"><path d="${frame}"/><path d="${path}"/></svg>`;
    module2.exports = { ENTER_ICON: svg(enter), EXIT_ICON: svg(exit) };
  }
});

// src/index.js
var { Plugin, Setting, getFrontend, getBackend, showMessage } = require("siyuan");
var css = require_styles();
var uiCss = require_ui();
var { name: pluginName, version: pluginVersion } = require_plugin();
var { ACTION_GROUPS, normalizeSettings, clamp, orbPosition, plainLabel, stripShortcuts, discoverActions, tabsOverflow } = require_core();
var { ENTER_ICON, EXIT_ICON } = require_icons();
var STORE = "preferences.json";
var CONTROL_ICONS = {
  settings: "iconSettings",
  minimize: "iconMin",
  maximize: "iconMax",
  restore: "iconRestore",
  close: "iconClose"
};
function button(label, className, callback) {
  const element = document.createElement("button");
  element.type = "button";
  element.className = className;
  element.textContent = label;
  element.addEventListener("click", callback);
  return element;
}
function setButtonIcon(element, label, icon) {
  element.title = label;
  element.setAttribute("aria-label", label);
  element.innerHTML = icon === "exit" ? EXIT_ICON : `<svg aria-hidden="true" fill="currentColor"><use href="#${CONTROL_ICONS[icon]}" xlink:href="#${CONTROL_ICONS[icon]}"></use></svg>`;
}
function iconButton(key, label, icon, callback) {
  const element = button("", "sim-window-button", callback);
  element.dataset.controlKey = key;
  setButtonIcon(element, label, icon);
  return element;
}
module.exports = class ImmersiveMode extends Plugin {
  async onload() {
    this.disposed = false;
    this.active = false;
    this.settingsData = normalizeSettings(null);
    this.cleanups = [];
    this.pendingSave = Promise.resolve();
    this.nativeReveals = /* @__PURE__ */ new Set();
    this.actionPositions = /* @__PURE__ */ new WeakMap();
    this.knownMenuSources = /* @__PURE__ */ new WeakSet();
    this.childMenuPositions = /* @__PURE__ */ new Map();
    this.defaultPageTools = /* @__PURE__ */ new Set();
    this.geometryRestores = /* @__PURE__ */ new Set();
    this.markedRows = /* @__PURE__ */ new Set();
    this.mergedRows = /* @__PURE__ */ new Map();
    this.tabSwitchers = /* @__PURE__ */ new Map();
    this.tabResizeTargets = /* @__PURE__ */ new Set();
    this.topbarOverflow = /* @__PURE__ */ new Map();
    try {
      this.settingsData = normalizeSettings(await this.loadData(STORE));
    } catch (error) {
      console.warn("[immersive-mode] Settings unavailable", error);
    }
    if (this.disposed) return;
    this.frontend = getFrontend();
    if (!["desktop", "browser-desktop"].includes(this.frontend)) return;
    const backend = typeof getBackend === "function" ? getBackend() : "";
    this.isDesktopClient = this.frontend === "desktop" && ["windows", "linux", "darwin"].includes(backend);
    this.isWindowsDesktop = this.isDesktopClient && /^Win/i.test(navigator.platform) && backend === "windows";
    this.addCommand({ langKey: "toggleImmersive", langText: "\u5207\u6362\u6C89\u6D78\u6A21\u5F0F", hotkey: "\u2325\u21E7I", callback: () => this.toggle() });
    this.uiStyle = document.createElement("style");
    this.uiStyle.id = "sim-ui-style";
    this.uiStyle.textContent = uiCss;
    document.head.append(this.uiStyle);
    this.setting = new Setting({ width: "520px", height: "fit-content" });
    const openSettings = this.setting.open.bind(this.setting);
    this.setting.open = (...args) => {
      openSettings(...args);
      this.setting.dialog?.element?.classList.add("sim-settings-dialog");
      const content = this.setting.dialog?.element?.querySelector(".b3-dialog__content");
      if (content) {
        const version = document.createElement("div");
        version.className = "sim-settings-version";
        version.textContent = `${pluginName} \xB7 v${pluginVersion}`;
        content.append(version);
      }
    };
    this.setting.addItem({ title: "\u684C\u9762\u5BA2\u6237\u7AEF\uFF1A\u4FDD\u7559\u9876\u90E8\u5DE5\u5177\u680F", description: "\u5DE5\u5177\u4E0E\u9875\u7B7E\u4FDD\u7559\u5728\u9876\u90E8\uFF0C\u4EC5\u684C\u9762\u5BA2\u6237\u7AEF\u751F\u6548\u3002", createActionElement: () => {
      const toggle = document.createElement("input");
      toggle.type = "checkbox";
      toggle.className = "b3-switch";
      toggle.setAttribute("aria-label", "\u684C\u9762\u5BA2\u6237\u7AEF\uFF1A\u4FDD\u7559\u9876\u90E8\u5DE5\u5177\u680F");
      toggle.checked = this.settingsData.windowsTopBar;
      toggle.disabled = !this.isDesktopClient;
      toggle.addEventListener("change", () => {
        if (!this.isDesktopClient) return;
        this.settingsData.windowsTopBar = toggle.checked;
        this.applyTopBarSetting();
        this.savePreferences();
      });
      return toggle;
    } });
    this.setting.addItem({ title: "\u542F\u52A8\u601D\u6E90\u65F6\u8FDB\u5165\u6C89\u6D78\u6A21\u5F0F", description: "\u601D\u6E90\u754C\u9762\u542F\u52A8\u5B8C\u6210\u540E\u81EA\u52A8\u8FDB\u5165\u6C89\u6D78\u6A21\u5F0F\uFF0C\u9ED8\u8BA4\u5173\u95ED\u3002", createActionElement: () => {
      const toggle = document.createElement("input");
      toggle.type = "checkbox";
      toggle.className = "b3-switch";
      toggle.setAttribute("aria-label", "\u542F\u52A8\u601D\u6E90\u65F6\u8FDB\u5165\u6C89\u6D78\u6A21\u5F0F");
      toggle.checked = this.settingsData.autoEnterOnResourceOpen;
      toggle.addEventListener("change", () => {
        this.settingsData.autoEnterOnResourceOpen = toggle.checked;
        this.savePreferences();
      });
      return toggle;
    } });
    this.setting.addItem({ title: "\u9875\u7B7E\u9ED8\u8BA4\u5C55\u793A\u6570\u91CF", description: "\u60AC\u6D6E\u83DC\u5355\u663E\u793A 1\u201320 \u4E2A\u9875\u7B7E\uFF0C\u8D85\u51FA\u6298\u53E0\u3002", createActionElement: () => {
      const input = document.createElement("input");
      input.type = "number";
      input.min = "1";
      input.max = "20";
      input.step = "1";
      input.className = "b3-text-field";
      input.style.width = "72px";
      input.setAttribute("aria-label", "\u9875\u7B7E\u9ED8\u8BA4\u5C55\u793A\u6570\u91CF");
      input.value = String(this.settingsData.tabPreviewCount);
      const applyCount = () => {
        const value = input.value.trim() ? Number(input.value) : NaN;
        const count = normalizeSettings({ tabPreviewCount: value }).tabPreviewCount;
        input.value = String(count);
        if (count === this.settingsData.tabPreviewCount) return;
        this.settingsData.tabPreviewCount = count;
        this.tabsExpanded = false;
        this.renderMenu();
        this.savePreferences();
      };
      input.addEventListener("change", applyCount);
      input.addEventListener("input", () => {
        if (input.value !== "" && input.validity.valid) applyCount();
      });
      return input;
    } });
  }
  onLayoutReady() {
    if (this.disposed || !["desktop", "browser-desktop"].includes(this.frontend) || this.topButton?.isConnected) return;
    this.topButton = this.addTopBar({
      icon: ENTER_ICON,
      title: "\u8FDB\u5165\u6C89\u6D78\u6A21\u5F0F \xB7 Alt+Shift+I",
      position: "right",
      callback: (event) => {
        event?.stopPropagation?.();
        this.deferTopButtonIcon = true;
        try {
          this.toggle();
        } finally {
          this.deferTopButtonIcon = false;
        }
      }
    });
    this.topButton?.classList.add("sim-immersive-entry");
    this.updateTopButton();
    if (this.settingsData.autoEnterOnResourceOpen) {
      window.requestAnimationFrame(() => {
        if (!this.disposed && !this.active && this.topButton?.isConnected) this.enter();
      });
    }
  }
  updateTopButton() {
    if (!this.topButton) return;
    this.topButton.removeAttribute("title");
    this.topButton.classList.add("ariaLabel");
    this.topButton.setAttribute("aria-label", `${this.active ? "\u9000\u51FA" : "\u8FDB\u5165"}\u6C89\u6D78\u6A21\u5F0F \xB7 Alt+Shift+I`);
    const updateIcon = () => {
      this.topButtonIconFrame = null;
      if (this.topButton?.isConnected) this.topButton.innerHTML = this.active ? EXIT_ICON : ENTER_ICON;
    };
    if (this.deferTopButtonIcon) {
      if (this.topButtonIconFrame != null) window.cancelAnimationFrame(this.topButtonIconFrame);
      this.topButtonIconFrame = window.requestAnimationFrame(updateIcon);
    } else {
      if (this.topButtonIconFrame != null) window.cancelAnimationFrame(this.topButtonIconFrame);
      updateIcon();
    }
  }
  configureResourceAutoEnter() {
    this.resourceObserver?.disconnect();
    this.resourceObserver = null;
    if (this.resourceEnterFrame != null) window.cancelAnimationFrame(this.resourceEnterFrame);
    this.resourceEnterFrame = null;
    this.pendingResourceTabs = /* @__PURE__ */ new Set();
    if (this.disposed || !this.settingsData.autoEnterOnResourceOpen || !this.topButton?.isConnected) return;
    const center = document.querySelector(".layout__center");
    if (!center) return;
    const selector = ".layout-tab-bar:not(.layout-tab-bar--readonly) > [data-id]";
    this.knownResourceTabs = new WeakSet(center.querySelectorAll(selector));
    this.resourceObserver = new MutationObserver((records) => {
      for (const record of records) {
        const target = record.target;
        if (target.closest(".layout-tab-container, .protyle")) continue;
        for (const node of record.addedNodes) {
          if (node.nodeType !== 1) continue;
          const tabs = node.matches(selector) ? [node] : node.querySelectorAll(selector);
          for (const tab of tabs) {
            if (!this.knownResourceTabs.has(tab)) {
              this.knownResourceTabs.add(tab);
              if (!this.active) this.pendingResourceTabs.add(tab);
            }
          }
        }
      }
      if (!this.pendingResourceTabs.size || this.active || this.resourceEnterFrame != null) return;
      this.resourceEnterFrame = window.requestAnimationFrame(() => {
        this.resourceEnterFrame = null;
        const opened = [...this.pendingResourceTabs].some((tab) => center.contains(tab) && tab.matches(selector));
        this.pendingResourceTabs.clear();
        if (opened && !this.disposed && this.settingsData.autoEnterOnResourceOpen && !this.active) this.enter();
      });
    });
    this.resourceObserver.observe(center, { childList: true, subtree: true });
  }
  listen(target, type, fn, options) {
    target.addEventListener(type, fn, options);
    this.cleanups.push(() => target.removeEventListener(type, fn, options));
  }
  savePreferences() {
    const snapshot = normalizeSettings(this.settingsData);
    this.pendingSave = this.pendingSave.then(() => this.saveData(STORE, snapshot)).catch((error) => {
      console.error("[immersive-mode] Save failed", error);
      if (!this.disposed) showMessage("\u6C89\u6D78\u6A21\u5F0F\uFF1A\u8BBE\u7F6E\u4FDD\u5B58\u5931\u8D25\uFF0C\u672C\u6B21\u4FEE\u6539\u53EF\u80FD\u65E0\u6CD5\u5728\u91CD\u542F\u540E\u4FDD\u7559\u3002", 5e3, "error");
    });
    return this.pendingSave;
  }
  toggle() {
    if (this.active) this.leave();
    else this.enter();
  }
  enter() {
    if (this.active || this.disposed || !this.topButton?.isConnected) return;
    try {
      discoverActions(document, this.topButton, this.app?.plugins, this.actionPositions);
      this.active = true;
      this.styleElement = document.createElement("style");
      this.styleElement.id = "sim-style";
      this.styleElement.textContent = css;
      document.head.append(this.styleElement);
      this.orb = button("", "sim-orb", () => {
        if (this.suppressClick) {
          this.suppressClick = false;
          return;
        }
        if (this.menu && this.menuOpenedByHover) {
          this.menuOpenedByHover = false;
          this.menu.querySelector("button")?.focus({ preventScroll: true });
          return;
        }
        if (this.menu) this.closeMenu();
        else this.openMenu();
      });
      this.orb.title = "\u6C89\u6D78\u6A21\u5F0F \xB7 \u60AC\u505C\u5C55\u5F00\u529F\u80FD / \u62D6\u52A8\u8C03\u6574\u4F4D\u7F6E";
      this.orb.setAttribute("aria-label", "\u6C89\u6D78\u6A21\u5F0F\u529F\u80FD\u83DC\u5355");
      this.orb.setAttribute("aria-expanded", "false");
      this.orb.setAttribute("aria-haspopup", "dialog");
      document.body.append(this.orb);
      this.listen(this.orb, "pointerenter", (event) => {
        if (event.pointerType !== "mouse" || event.buttons || this.drag || this.menu) return;
        this.openMenu(false);
        this.menuOpenedByHover = true;
      });
      if (this.isDesktopClient) {
        this.dragRegion = document.createElement("div");
        this.dragRegion.className = "sim-window-drag";
        this.dragRegion.title = "\u62D6\u52A8\u79FB\u52A8\u7A97\u53E3";
        this.dragRegion.setAttribute("aria-hidden", "true");
        document.body.append(this.dragRegion);
      }
      document.body.classList.add("sim-active");
      this.applyTopBarSetting();
      this.showDefaultPageTools();
      this.updateTopButton();
      this.markLayoutRows();
      this.bindOrbDrag();
      this.placeOrb();
      this.listen(window, "resize", () => {
        this.placeOrb();
        this.placeMenu();
        this.queueMergedTabs();
      });
      this.listen(document, "pointerdown", (event) => {
        if (!this.menu?.contains(event.target) && !this.windowActions?.contains(event.target) && !this.submenu?.contains(event.target) && !this.orb.contains(event.target)) this.closeMenu();
        if (![...this.nativeReveals].some((el) => el.contains(event.target))) this.clearNativeTools(true);
      }, true);
      this.listen(document, "keydown", (event) => {
        if (event.key === "Escape" && this.submenu) {
          if (this.submenu.querySelector(".b3-menu__item--show")) return;
          event.preventDefault();
          event.stopPropagation();
          this.closeSubmenu(true);
          return;
        }
        if (event.key === "Escape" && (this.menu || this.nativeReveals.size)) {
          event.preventDefault();
          event.stopPropagation();
          this.closeMenu(true);
          this.clearNativeTools(true);
        }
      }, true);
      this.observer = new MutationObserver((records) => {
        if (records.every((record) => record.target.id === "barSync" && record.type === "attributes" && ["aria-label", "data-title", "title"].includes(record.attributeName))) {
          this.updateSyncTip();
          return;
        }
        if (!records.some((record) => !(record.target.nodeType === 1 ? record.target : record.target.parentElement)?.closest(".layout-tab-container, .protyle"))) return;
        this.syncDefaultPageTools();
        this.updateWindowButtons();
        if (!this.menu || this.refreshTimer) return;
        this.refreshTimer = setTimeout(() => {
          this.refreshTimer = null;
          if (this.active && this.menu) this.renderMenu();
        }, 120);
      });
      document.querySelectorAll("#toolbar, #dockLeft, #dockRight, #dockBottom, .layout__center").forEach((el) => this.observer.observe(el, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ["class", "aria-label", "aria-selected", "aria-disabled", "disabled", "data-title", "title", "hidden"] }));
      if (this.isDesktopClient) {
        this.windowStateObserver = new MutationObserver(() => this.updateWindowButtons());
        this.windowStateObserver.observe(document.body, { attributes: true, attributeFilter: ["class"] });
      }
    } catch (error) {
      this.leave();
      console.error("[immersive-mode] Enter failed", error);
      showMessage("\u6C89\u6D78\u6A21\u5F0F\u521D\u59CB\u5316\u5931\u8D25\uFF0C\u5DF2\u6062\u590D\u666E\u901A\u754C\u9762\u3002", 5e3, "error");
    }
  }
  markLayoutRows() {
    const center = document.querySelector(".layout__center");
    if (!center) return;
    const row = center.parentElement;
    if (row && !row.classList.contains("sim-layout-row")) {
      row.classList.add("sim-layout-row");
      this.markedRows.add(row);
    }
  }
  applyTopBarSetting() {
    const keep = this.active && this.isDesktopClient && this.settingsData.windowsTopBar;
    this.clearNativeTools(true);
    document.body.classList.toggle("sim-window-strip", !!keep);
    document.body.classList.toggle("sim-keep-topbar", !!keep);
    if (keep) this.startMergedTabs();
    else this.stopMergedTabs();
    if (this.menu) this.renderMenu();
    this.placeMenu();
  }
  startMergedTabs() {
    if (!this.tabMergeObserver) {
      this.tabMergeObserver = new MutationObserver((records) => {
        if (records.some((record) => !(record.target.nodeType === 1 ? record.target : record.target.parentElement)?.closest(".layout-tab-container, .protyle"))) this.queueMergedTabs();
      });
      document.querySelectorAll("#toolbar, .layout__center").forEach((element) => this.tabMergeObserver.observe(element, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ["class", "style", "hidden"]
      }));
      if (window.ResizeObserver) this.tabResizeObserver = new window.ResizeObserver(() => this.queueMergedTabs());
    }
    this.syncMergedTabs();
  }
  queueMergedTabs() {
    if (!this.tabMergeObserver || this.tabLayoutFrame != null) return;
    this.tabLayoutFrame = window.requestAnimationFrame(() => {
      this.tabLayoutFrame = null;
      this.syncMergedTabs();
    });
  }
  fitTopbarTools(pageLeft) {
    const toolbar = document.getElementById("toolbar");
    if (!toolbar) return;
    const style = window.getComputedStyle(toolbar);
    const gap = parseFloat(style.columnGap) || 0;
    let right = toolbar.getBoundingClientRect().left + (parseFloat(style.paddingLeft) || 0);
    for (const child of toolbar.children) {
      if (child.id === "drag") break;
      if (child.matches(".fn__none, [hidden]")) continue;
      const hidden = child.classList.contains("sim-topbar-overflow");
      const childStyle = window.getComputedStyle(child);
      const width = hidden ? this.topbarOverflow.get(child) : child.getBoundingClientRect().width + (parseFloat(childStyle.marginLeft) || 0) + (parseFloat(childStyle.marginRight) || 0);
      if (!width) continue;
      right += width + gap;
      const overflow = right > pageLeft;
      if (overflow && !hidden) {
        this.topbarOverflow.set(child, width);
        child.classList.add("sim-topbar-overflow");
      } else if (!overflow && hidden) {
        child.classList.remove("sim-topbar-overflow");
        this.topbarOverflow.delete(child);
      }
    }
  }
  syncMergedTabs() {
    if (!this.tabMergeObserver) return;
    const drag = document.querySelector("#toolbar #drag");
    const candidates = [];
    for (const wnd of document.querySelectorAll('.layout__center [data-type="wnd"]')) {
      if (wnd.closest(".fn__none, [hidden]") || window.getComputedStyle(wnd).display === "none") continue;
      const bounds = wnd.getBoundingClientRect();
      if (!bounds.width || !bounds.height) continue;
      const row = [...wnd.children].find((element) => element.classList.contains("fn__flex") && [...element.children].some((child) => child.classList.contains("layout-tab-bar")));
      if (!row || row.matches(".fn__none, [hidden]")) continue;
      const page = wnd.querySelector(":scope > .layout-tab-container");
      const pageRect = page?.getBoundingClientRect();
      candidates.push({ row, wnd, page, bounds: pageRect?.width ? pageRect : bounds });
    }
    if (candidates.length) this.fitTopbarTools(Math.min(...candidates.map((item) => item.bounds.left)));
    const rect = drag?.getBoundingClientRect();
    candidates.sort((a, b) => a.bounds.left - b.bounds.left || Number(b.wnd.classList.contains("layout__wnd--active")) - Number(a.wnd.classList.contains("layout__wnd--active")));
    const slots = candidates.map(({ bounds }, index) => {
      if (index && bounds.left === candidates[index - 1].bounds.left) return null;
      const next = candidates.slice(index + 1).find((item) => item.bounds.left > bounds.left);
      const end = Math.min(bounds.right, next ? next.bounds.left - 4 : innerWidth - 8, rect ? rect.right - 48 : innerWidth - 8);
      return { left: bounds.left, width: Math.max(0, end - bounds.left) };
    });
    const nextRows = /* @__PURE__ */ new Set();
    candidates.forEach(({ row }, index) => {
      const slot = slots[index];
      if (!slot || slot.width < 1) return;
      nextRows.add(row);
      if (!this.mergedRows.has(row)) this.mergedRows.set(row, {
        hadClass: row.classList.contains("sim-merged-tabs"),
        props: ["--sim-tabs-left", "--sim-tabs-width"].map((key) => [key, row.style.getPropertyValue(key), row.style.getPropertyPriority(key)])
      });
      if (!row.classList.contains("sim-merged-tabs")) row.classList.add("sim-merged-tabs");
      for (const [key, value] of [["--sim-tabs-left", slot.left], ["--sim-tabs-width", slot.width]]) {
        const cssValue = `${Math.round(value * 100) / 100}px`;
        if (row.style.getPropertyValue(key) !== cssValue) row.style.setProperty(key, cssValue);
      }
    });
    for (const row of this.mergedRows.keys()) if (!nextRows.has(row)) this.restoreMergedRow(row);
    const tabTargets = this.syncTabSwitchers(nextRows);
    const targets = new Set([drag, document.getElementById("toolbar"), ...candidates.flatMap((item) => [item.wnd, item.page]), ...tabTargets].filter(Boolean));
    for (const target of this.tabResizeTargets) if (!targets.has(target)) this.tabResizeObserver?.unobserve(target);
    for (const target of targets) if (!this.tabResizeTargets.has(target)) this.tabResizeObserver?.observe(target);
    this.tabResizeTargets = targets;
  }
  syncTabSwitchers(rows) {
    const current = /* @__PURE__ */ new Set();
    const resizeTargets = [];
    for (const row of rows) {
      const list = [...row.children].find((element) => element.classList.contains("layout-tab-bar") && !element.classList.contains("layout-tab-bar--readonly"));
      const readonly = row.querySelector(".layout-tab-bar--readonly");
      if (!list || !readonly) continue;
      resizeTargets.push(list, readonly, ...list.children);
      const switchers = [...readonly.querySelectorAll('[data-type="more"]')];
      const visibleWidth = switchers.reduce((sum, element) => {
        const style = window.getComputedStyle(element);
        if (style.display === "none") return sum;
        return sum + element.getBoundingClientRect().width + (parseFloat(style.marginLeft) || 0) + (parseFloat(style.marginRight) || 0);
      }, 0);
      const overflow = tabsOverflow(list.scrollWidth, list.clientWidth, visibleWidth);
      for (const element of switchers) {
        current.add(element);
        if (!this.tabSwitchers.has(element)) this.tabSwitchers.set(element, { row, hadClass: element.classList.contains("sim-tab-switch-hidden") });
        if (element.classList.contains("sim-tab-switch-hidden") !== !overflow) element.classList.toggle("sim-tab-switch-hidden", !overflow);
      }
    }
    for (const element of this.tabSwitchers.keys()) if (!current.has(element)) this.restoreTabSwitcher(element);
    return resizeTargets;
  }
  restoreTabSwitcher(element) {
    const saved = this.tabSwitchers.get(element);
    if (!saved) return;
    element.classList.toggle("sim-tab-switch-hidden", saved.hadClass);
    this.tabSwitchers.delete(element);
  }
  restoreMergedRow(row) {
    const saved = this.mergedRows.get(row);
    if (!saved) return;
    if (!saved.hadClass) row.classList.remove("sim-merged-tabs");
    for (const [key, value, priority] of saved.props) {
      if (value) row.style.setProperty(key, value, priority);
      else row.style.removeProperty(key);
    }
    this.mergedRows.delete(row);
    for (const [element, state] of this.tabSwitchers) if (state.row === row) this.restoreTabSwitcher(element);
  }
  stopMergedTabs() {
    this.tabMergeObserver?.disconnect();
    this.tabMergeObserver = null;
    this.tabResizeObserver?.disconnect();
    this.tabResizeObserver = null;
    this.tabResizeTargets.clear();
    if (this.tabLayoutFrame != null) window.cancelAnimationFrame(this.tabLayoutFrame);
    this.tabLayoutFrame = null;
    for (const row of this.mergedRows.keys()) this.restoreMergedRow(row);
    for (const element of this.tabSwitchers.keys()) this.restoreTabSwitcher(element);
    for (const element of this.topbarOverflow.keys()) element.classList.remove("sim-topbar-overflow");
    this.topbarOverflow.clear();
  }
  bindOrbDrag() {
    const orb = this.orb;
    this.listen(orb, "pointerdown", (event) => {
      if (event.button !== 0) return;
      this.suppressClick = false;
      const rect = orb.getBoundingClientRect();
      this.drag = { id: event.pointerId, x: event.clientX, y: event.clientY, left: rect.left, top: rect.top, moved: false };
      orb.setPointerCapture?.(event.pointerId);
    });
    this.listen(window, "pointermove", (event) => {
      const drag = this.drag;
      if (!drag || drag.id !== event.pointerId) return;
      const dx = event.clientX - drag.x, dy = event.clientY - drag.y;
      if (!drag.moved && Math.hypot(dx, dy) < 5) return;
      drag.moved = true;
      this.closeMenu();
      orb.style.left = `${clamp(drag.left + dx, 8, innerWidth - 50)}px`;
      orb.style.top = `${clamp(drag.top + dy, 8, innerHeight - 50)}px`;
    });
    const finish = (event) => {
      if (!this.drag || this.drag.id !== event.pointerId) return;
      const drag = this.drag;
      this.drag = null;
      if (drag.moved) {
        this.suppressClick = true;
        this.settingsData.side = parseFloat(orb.style.left) + 16 < innerWidth / 2 ? "left" : "right";
        this.settingsData.y = clamp(parseFloat(orb.style.top) / Math.max(1, innerHeight - 42), 0, 1);
        this.placeOrb();
        this.savePreferences();
      }
      if (orb.hasPointerCapture?.(event.pointerId)) orb.releasePointerCapture(event.pointerId);
    };
    this.listen(window, "pointerup", finish);
    this.listen(window, "pointercancel", finish);
    this.listen(window, "blur", () => {
      this.drag = null;
      this.placeOrb();
    });
  }
  placeOrb() {
    if (!this.orb) return;
    const point = orbPosition(this.settingsData, innerWidth, innerHeight);
    this.orb.style.left = `${point.x}px`;
    this.orb.style.top = `${point.y}px`;
  }
  openMenu(focus = true) {
    this.clearNativeTools(true);
    this.closeMenu();
    this.tabsExpanded = false;
    this.menu = document.createElement("section");
    this.menu.className = "sim-menu";
    this.menu.setAttribute("role", "dialog");
    this.menu.setAttribute("aria-label", "\u6C89\u6D78\u6A21\u5F0F\u529F\u80FD");
    this.menu.tabIndex = -1;
    this.menu.addEventListener("scroll", () => {
      this.placeSubmenu();
      this.updateSyncTip();
    }, true);
    this.menu.addEventListener("wheel", (event) => {
      if (this.submenu) event.stopPropagation();
    }, { passive: true });
    document.body.append(this.menu);
    this.orb.classList.add("sim-orb--active");
    this.orb.setAttribute("aria-expanded", "true");
    this.renderMenu();
    if (focus) this.menu.querySelector("button")?.focus({ preventScroll: true });
  }
  actions() {
    return [
      ...discoverActions(document, this.topButton, this.app?.plugins, this.actionPositions).filter((action) => !document.body.classList.contains("sim-keep-topbar") || action.group !== "top" || action.element.closest(".sim-topbar-overflow")).map((action) => ({ ...action, hasSubmenu: action.hasSubmenu || this.knownMenuSources.has(action.element), run: () => this.invokeSource(action.element) })),
      ...!document.body.classList.contains("sim-keep-topbar") ? [{ key: "builtin:toolbar", title: "\u539F\u751F\u5DE5\u5177\u680F\uFF08\u624B\u52A8\u5C55\u5F00\uFF09", icon: "iconMenu", origin: "\u8865\u5145", group: "top", run: () => this.revealToolbar() }] : []
    ];
  }
  renderMenu() {
    if (!this.menu) return;
    this.hideSyncTip();
    this.cancelSubmenuHover();
    const focusedKey = document.activeElement?.dataset?.actionKey;
    const focusedControl = document.activeElement?.dataset?.controlKey;
    const focusedTab = document.activeElement?.dataset?.tabKey;
    const focusedToggle = document.activeElement?.classList.contains("sim-tabs-toggle");
    const oldScroll = this.menu.querySelector(".sim-menu-other-scroll")?.scrollTop || 0;
    this.menu.className = "sim-menu";
    this.menu.replaceChildren();
    const header = document.createElement("div");
    header.className = "sim-menu-header";
    const title = document.createElement("strong");
    title.textContent = "Immersive \u6C89\u6D78\u6A21\u5F0F";
    header.append(title);
    if (!this.isDesktopClient) {
      const exit = iconButton("exit", "\u9000\u51FA\u6C89\u6D78", "exit", () => this.leave());
      exit.classList.add("sim-header-exit");
      header.append(exit);
    }
    const keepTopbar = this.isDesktopClient && this.settingsData.windowsTopBar;
    const tabPanel = keepTopbar ? null : this.createTabPanel();
    const scroll = document.createElement("div");
    scroll.className = "sim-menu-other-scroll";
    if (tabPanel) scroll.append(tabPanel);
    scroll.addEventListener("scroll", () => this.closeSubmenu(), { passive: true });
    const actions = this.actions();
    const sections = ACTION_GROUPS.map(([group, title2]) => ({ group, title: title2, items: actions.filter((action) => action.group === group) }));
    for (const { group, title: title2, items } of sections) {
      if (!items.length) continue;
      const container = document.createElement("section");
      container.className = "sim-action-group";
      container.dataset.actionGroup = group;
      scroll.append(container);
      const heading = document.createElement("h3");
      heading.textContent = title2;
      const count = document.createElement("small");
      count.textContent = String(items.length);
      heading.append(count);
      container.append(heading);
      for (const action of items) {
        const row = document.createElement("div");
        row.className = "sim-row";
        const dock = action.element?.classList.contains("dock__item");
        if (dock) {
          row.classList.add("sim-row--dock");
          row.classList.toggle("sim-row--active", action.element.classList.contains("dock__item--active"));
          row.classList.toggle("sim-row--activefocus", action.element.classList.contains("dock__item--activefocus"));
        }
        const launch = button("", `sim-action${action.hasSubmenu ? " sim-action--submenu" : ""}`, (event) => {
          event.stopPropagation();
          if (action.mayOpenMenu) this.openSubmenu(action);
          else this.runAction(action);
        });
        launch.dataset.actionKey = action.key;
        if (action.element?.id !== "barSync") launch.title = action.title;
        launch.setAttribute("aria-label", action.title);
        if (dock) launch.setAttribute("aria-pressed", String(action.element.matches(".dock__item--active, .dock__item--activefocus")));
        if (action.hasSubmenu) {
          launch.setAttribute("aria-haspopup", "dialog");
          launch.setAttribute("aria-expanded", String(this.submenuAction?.key === action.key));
        }
        row.addEventListener("pointerenter", (event) => {
          if (event.pointerType !== "mouse" || event.buttons || this.drag) return;
          this.cancelSubmenuHover();
          if (this.submenuAction && this.submenuAction.key !== action.key) this.closeSubmenu();
          if (action.element?.id === "barSync") this.showSyncTip(launch, action.element);
          if (!action.hasSubmenu) return;
          this.submenuHoverTimer = setTimeout(() => {
            this.submenuHoverTimer = null;
            if (this.active && row.isConnected && !this.drag) this.openSubmenu(action, true);
          }, 180);
        });
        row.addEventListener("pointerleave", () => {
          this.cancelSubmenuHover();
          if (action.element?.id === "barSync") this.hideSyncTip();
        });
        if (action.element?.id === "barSync") {
          launch.addEventListener("focus", () => this.showSyncTip(launch, action.element));
          launch.addEventListener("blur", () => this.hideSyncTip());
        }
        const sourceIcon = action.element?.querySelector("svg use");
        const href = sourceIcon?.getAttribute("xlink:href") || sourceIcon?.getAttribute("href") || (action.icon ? `#${action.icon.replace(/^#/, "")}` : "");
        if (href?.startsWith("#")) {
          const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
          svg.setAttribute("aria-hidden", "true");
          const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
          use.setAttribute("href", href);
          svg.append(use);
          launch.append(svg);
        } else {
          const icon = document.createElement("span");
          icon.textContent = "\u25C7";
          icon.setAttribute("aria-hidden", "true");
          launch.append(icon);
        }
        const label = document.createElement("span");
        label.className = "sim-action-label";
        label.textContent = action.title;
        launch.append(label);
        if (action.hasSubmenu) {
          const arrow = document.createElement("span");
          arrow.className = "sim-submenu-chevron";
          arrow.textContent = "\u203A";
          arrow.setAttribute("aria-hidden", "true");
          launch.append(arrow);
        }
        row.append(launch);
        container.append(row);
      }
    }
    const settingsRow = document.createElement("div");
    settingsRow.className = "sim-row sim-plugin-settings";
    const settings = button("", "sim-action", () => {
      this.closeMenu();
      this.setting.open("Immersive \u6C89\u6D78\u6A21\u5F0F\u8BBE\u7F6E");
    });
    settings.dataset.actionKey = "builtin:plugin-settings";
    setButtonIcon(settings, "\u63D2\u4EF6\u8BBE\u7F6E", "settings");
    const settingsLabel = document.createElement("span");
    settingsLabel.textContent = "\u63D2\u4EF6\u8BBE\u7F6E";
    settings.append(settingsLabel);
    settingsRow.append(settings);
    scroll.append(settingsRow);
    settingsRow.addEventListener("pointerenter", (event) => {
      if (event.pointerType === "mouse" && !event.buttons) this.closeSubmenu();
    });
    this.windowActions?.remove();
    this.windowActions = null;
    this.menu.append(header);
    this.menu.append(scroll);
    if (!keepTopbar && this.isDesktopClient) {
      this.menu.append(this.createWindowActions());
    }
    this.updateWindowButtons();
    scroll.scrollTop = oldScroll;
    this.placeMenu();
    if (this.submenuAction) {
      const current = actions.find((action) => action.key === this.submenuAction.key);
      if (current) this.submenuAction = current;
      else this.closeSubmenu();
    }
    if (focusedKey) [...this.menu.querySelectorAll(".sim-action")].find((el) => el.dataset.actionKey === focusedKey)?.focus({ preventScroll: true });
    if (focusedTab) [...this.menu.querySelectorAll(".sim-tab")].find((el) => el.dataset.tabKey === focusedTab)?.focus({ preventScroll: true });
    if (focusedToggle) this.menu.querySelector(".sim-tabs-toggle")?.focus({ preventScroll: true });
    if (focusedControl) this.menu.querySelector(`[data-control-key="${focusedControl}"]`)?.focus({ preventScroll: true });
  }
  createWindowActions() {
    const actions = document.createElement("div");
    actions.className = "sim-window-actions sim-control-dock";
    actions.setAttribute("role", "toolbar");
    actions.setAttribute("aria-label", "\u7A97\u53E3\u4E0E\u6C89\u6D78\u6A21\u5F0F\u63A7\u5236");
    actions.append(
      iconButton("exit", "\u9000\u51FA\u6C89\u6D78", "exit", () => this.leave()),
      iconButton("minimize", "\u6700\u5C0F\u5316", "minimize", () => this.invokeWindowControl("minWindow")),
      iconButton("maximize", "\u6700\u5927\u5316", "maximize", () => this.invokeWindowControl(document.body.classList.contains("body--maximize") ? "restoreWindow" : "maxWindow")),
      iconButton("close", "\u5173\u95ED\u7A97\u53E3", "close", () => this.invokeWindowControl("closeWindow"))
    );
    this.windowActions = actions;
    actions.addEventListener("pointerenter", (event) => {
      if (event.pointerType === "mouse" && !event.buttons) this.closeSubmenu();
    });
    return actions;
  }
  updateWindowButtons() {
    if (!this.windowActions || !this.isDesktopClient) return;
    const maximized = document.body.classList.contains("body--maximize");
    const maximize = this.windowActions.querySelector('[data-control-key="maximize"]');
    if (maximize) setButtonIcon(maximize, maximized ? "\u8FD8\u539F" : "\u6700\u5927\u5316", maximized ? "restore" : "maximize");
    for (const [key, id] of [["minimize", "minWindow"], ["maximize", maximized ? "restoreWindow" : "maxWindow"], ["close", "closeWindow"]]) {
      const control = this.windowActions.querySelector(`[data-control-key="${key}"]`);
      const source = document.getElementById(id);
      if (control) control.disabled = !source || source.matches('[disabled], [aria-disabled="true"]');
    }
  }
  invokeWindowControl(id) {
    if (!this.isDesktopClient) return;
    const source = document.getElementById(id);
    if (!source || source.matches('[disabled], [aria-disabled="true"]')) return;
    this.closeMenu();
    source.click();
  }
  cancelSubmenuHover() {
    clearTimeout(this.submenuHoverTimer);
    this.submenuHoverTimer = null;
  }
  showSyncTip(anchor, source) {
    if (this.syncTipAnchor === anchor) return;
    this.hideSyncTip();
    this.syncTipAnchor = anchor;
    this.syncTipSource = source;
    this.syncTip = document.createElement("div");
    this.syncTip.className = "sim-sync-tip";
    this.syncTip.id = "sim-sync-tip";
    this.syncTip.setAttribute("role", "tooltip");
    anchor.setAttribute("aria-describedby", this.syncTip.id);
    document.body.append(this.syncTip);
    this.updateSyncTip();
    source.dispatchEvent(new window.MouseEvent("mouseenter"));
  }
  updateSyncTip() {
    if (!this.syncTip || !this.syncTipAnchor?.isConnected) return;
    const source = this.syncTipSource;
    const raw = source.getAttribute("aria-label") || source.getAttribute("data-title") || source.title || "\u6682\u65E0\u540C\u6B65\u4FE1\u606F";
    const parser = document.createElement("template");
    parser.innerHTML = raw.replace(/<br\s*\/?\s*>/gi, "\n");
    this.syncTip.textContent = stripShortcuts(parser.content.textContent || "").trim() || "\u6682\u65E0\u540C\u6B65\u4FE1\u606F";
    const rect = this.syncTipAnchor.getBoundingClientRect();
    const bounds = this.syncTip.getBoundingClientRect();
    const left = this.settingsData.side === "right" ? this.menu.getBoundingClientRect().left - bounds.width - 6 : this.menu.getBoundingClientRect().right + 6;
    this.syncTip.style.left = `${clamp(left, 8, innerWidth - bounds.width - 8)}px`;
    this.syncTip.style.top = `${clamp(rect.top, 8, innerHeight - bounds.height - 8)}px`;
  }
  hideSyncTip() {
    this.syncTipAnchor?.removeAttribute("aria-describedby");
    this.syncTip?.remove();
    this.syncTip = null;
    this.syncTipAnchor = null;
    this.syncTipSource = null;
  }
  createTabPanel() {
    const panel = document.createElement("section");
    panel.className = "sim-menu-tabs";
    panel.addEventListener("pointerenter", (event) => {
      if (event.pointerType === "mouse" && !event.buttons) this.closeSubmenu();
    });
    const tabs = [...document.querySelectorAll(".layout__center .layout-tab-bar:not(.layout-tab-bar--readonly) > [data-id]")];
    const heading = document.createElement("h3");
    heading.textContent = "\u9875\u7B7E";
    const count = document.createElement("small");
    count.textContent = String(tabs.length);
    heading.append(count);
    const list = document.createElement("div");
    list.className = "sim-tab-list";
    list.setAttribute("aria-label", "\u5DF2\u6253\u5F00\u9875\u7B7E");
    if (!tabs.length) {
      const empty = document.createElement("p");
      empty.className = "sim-empty";
      empty.textContent = "\u6682\u65E0\u5DF2\u6253\u5F00\u9875\u7B7E";
      list.append(empty);
    }
    const visible = this.tabsExpanded ? tabs : tabs.slice(0, this.settingsData.tabPreviewCount);
    for (const tab of visible) {
      const name = tab.querySelector(".item__text")?.textContent?.trim() || plainLabel(tab) || "\u672A\u547D\u540D\u9875\u9762";
      const active = tab.classList.contains("item--focus");
      const row = document.createElement("div");
      row.className = "sim-tab-row";
      row.classList.toggle("sim-tab-row--active", active);
      const select = button("", "sim-tab", () => {
        this.closeMenu();
        if (tab.isConnected) tab.click();
      });
      select.dataset.tabKey = `${tab.closest('[data-type="wnd"]')?.dataset.id || ""}:${tab.dataset.id}`;
      select.title = name;
      select.setAttribute("aria-label", `\u5207\u6362\u9875\u7B7E\uFF1A${name}`);
      select.setAttribute("aria-current", String(active));
      const marker = document.createElement("span");
      marker.className = "sim-tab-marker";
      marker.textContent = active ? "\u25CF" : "\u25CB";
      marker.setAttribute("aria-hidden", "true");
      const label = document.createElement("span");
      label.className = "sim-tab-label";
      label.textContent = name;
      const close = iconButton("close-tab", `\u5173\u95ED\u9875\u7B7E\uFF1A${name}`, "close", (event) => {
        event.stopPropagation();
        if (!tab.isConnected) return;
        const nativeClose = tab.querySelector('.item__close, [data-type="close"]');
        if (nativeClose) nativeClose.click();
        else tab.dispatchEvent(new window.MouseEvent("auxclick", { bubbles: true, button: 1 }));
      });
      close.classList.add("sim-tab-close");
      select.append(marker, label);
      row.append(select, close);
      list.append(row);
    }
    panel.append(heading, list);
    const remaining = tabs.length - this.settingsData.tabPreviewCount;
    if (remaining > 0) {
      const toggle = button(this.tabsExpanded ? "\u6536\u8D77\u9875\u7B7E" : `\u5C55\u5F00\u5176\u4F59\u9875\u7B7E\uFF08${remaining}\uFF09`, "sim-tabs-toggle", () => {
        this.tabsExpanded = !this.tabsExpanded;
        this.renderMenu();
        this.menu?.querySelector(".sim-tabs-toggle")?.focus({ preventScroll: true });
      });
      toggle.setAttribute("aria-expanded", String(!!this.tabsExpanded));
      panel.append(toggle);
    }
    return panel;
  }
  runAction(action) {
    if (!action.keepOpen) this.closeMenu();
    try {
      action.run();
    } catch (error) {
      console.error("[immersive-mode] Action failed", error);
      showMessage("\u8BE5\u5165\u53E3\u672A\u80FD\u6253\u5F00\uFF0C\u53EF\u901A\u8FC7\u201C\u539F\u751F\u5DE5\u5177\u680F\u201D\u91CD\u8BD5\uFF0C\u6216 Alt+Shift+I \u9000\u51FA\u6C89\u6D78\u3002", 6e3, "error");
    }
  }
  openSubmenu(action, fromHover = false) {
    this.cancelSubmenuHover();
    if (!action?.mayOpenMenu) return this.runAction(action);
    if (this.submenuAction?.key === action.key) {
      if (fromHover) return;
      if (this.submenuOpenedByHover) {
        this.submenuOpenedByHover = false;
        return;
      }
      this.closeSubmenu(true);
      return;
    }
    this.closeSubmenu();
    this.submenuAction = action;
    this.submenuOpenedByHover = fromHover;
    this.menusBeforeAction = new Set(this.visibleNativeMenus());
    this.dialogsBeforeAction = new Set(document.querySelectorAll('.b3-dialog, dialog[open], [role="dialog"]'));
    this.nativeMenuObserver = new MutationObserver((records) => {
      if (records.some((record) => {
        const element = record.target.nodeType === 1 ? record.target : record.target.parentElement;
        return element === document.body || element?.closest(".b3-menu, .b3-dialog, dialog");
      })) this.syncSubmenu();
    });
    this.nativeMenuObserver.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "hidden"] });
    try {
      const anchor = this.menuActionElement(action.key)?.getBoundingClientRect();
      this.invokeSource(action.element, anchor);
      this.syncSubmenu();
      if (this.submenuAction && !this.submenu) this.submenuTimer = setTimeout(() => {
        this.submenuTimer = null;
        if (!this.submenu && this.submenuAction) this.closeMenu();
      }, 1500);
    } catch (error) {
      this.closeMenu();
      console.error("[immersive-mode] Native menu failed", error);
      showMessage("\u8BE5\u5165\u53E3\u672A\u80FD\u6253\u5F00\uFF0C\u53EF\u901A\u8FC7\u539F\u751F\u5DE5\u5177\u680F\u91CD\u8BD5\u3002", 5e3, "error");
    }
  }
  menuActionElement(key) {
    return [...this.menu?.querySelectorAll("[data-action-key]") || []].find((element) => element.dataset.actionKey === key);
  }
  visibleNativeMenus() {
    return [...document.querySelectorAll(".b3-menu")].filter((element) => {
      if (element.closest(".fn__none, .fn__hidden, [hidden], .protyle, .layout__center")) return false;
      const style = window.getComputedStyle(element);
      return style.display !== "none" && style.visibility !== "hidden";
    });
  }
  syncSubmenu() {
    if (!this.menu || !this.submenuAction) return;
    const visible = this.visibleNativeMenus();
    if (this.submenu) {
      if (!visible.includes(this.submenu)) {
        this.closeSubmenu(false, false);
        return;
      }
      this.placeSubmenu();
      return;
    }
    const element = visible.find((menu) => !this.menusBeforeAction.has(menu));
    if (!element) {
      const dialog = [...document.querySelectorAll('.b3-dialog, dialog[open], [role="dialog"]')].find((node) => !this.dialogsBeforeAction.has(node));
      if (dialog) this.closeMenu();
      return;
    }
    clearTimeout(this.submenuTimer);
    this.submenuTimer = null;
    this.submenu = element;
    this.knownMenuSources.add(this.submenuAction.element);
    this.submenuStyle = ["--sim-submenu-left", "--sim-submenu-top"].map((key) => [key, element.style.getPropertyValue(key), element.style.getPropertyPriority(key)]);
    this.submenuHadClass = element.classList.contains("sim-native-submenu");
    element.classList.add("sim-native-submenu");
    this.nativeMenuScrollHandler = () => this.placeSubmenu();
    element.addEventListener("scroll", this.nativeMenuScrollHandler, true);
    this.menuActionElement(this.submenuAction.key)?.setAttribute("aria-expanded", "true");
    this.placeSubmenu();
  }
  closeSubmenu(focusParent = false, dismiss = true) {
    this.cancelSubmenuHover();
    this.submenuOpenedByHover = false;
    const key = this.submenuAction?.key;
    const element = this.submenu;
    this.nativeMenuObserver?.disconnect();
    this.nativeMenuObserver = null;
    clearTimeout(this.submenuTimer);
    this.submenuTimer = null;
    this.submenu = null;
    this.submenuAction = null;
    this.menusBeforeAction = null;
    this.dialogsBeforeAction = null;
    if (element) {
      element.removeEventListener("scroll", this.nativeMenuScrollHandler, true);
      if (!this.submenuHadClass) element.classList.remove("sim-native-submenu");
      for (const [prop, value, priority] of this.submenuStyle || []) {
        if (value) element.style.setProperty(prop, value, priority);
        else element.style.removeProperty(prop);
      }
      const owner = Object.values(window.siyuan?.menus || {}).find((menu) => menu?.element === element);
      if (dismiss && owner?.remove) owner.remove();
    }
    this.nativeMenuScrollHandler = null;
    for (const [child, saved] of this.childMenuPositions) {
      if (!saved.hadClass) child.classList.remove("sim-child-positioned");
      if (saved.value) child.style.setProperty("--sim-child-top", saved.value, saved.priority);
      else child.style.removeProperty("--sim-child-top");
    }
    this.childMenuPositions.clear();
    this.submenuStyle = null;
    this.menuActionElement(key)?.setAttribute("aria-expanded", "false");
    if (focusParent) this.menuActionElement(key)?.focus({ preventScroll: true });
  }
  placeMenu() {
    if (!this.menu || !this.orb) return;
    const orb = this.orb.getBoundingClientRect();
    const { width, height } = this.menu.getBoundingClientRect();
    const x = this.settingsData.side === "right" ? orb.left - width - 10 : orb.right + 10;
    const left = clamp(x, 8, innerWidth - width - 8);
    const top = clamp(orb.top - height / 2 + 16, 8, innerHeight - height - 8);
    this.menu.style.left = `${left}px`;
    this.menu.style.top = `${top}px`;
    this.placeSubmenu();
    this.updateSyncTip();
  }
  placeSubmenu() {
    if (!this.submenu || !this.menu) return;
    const primary = this.menu.getBoundingClientRect();
    const { width, height } = this.submenu.getBoundingClientRect();
    const gap = 8;
    const preferRight = this.settingsData.side === "left";
    let x = preferRight ? primary.right + gap : primary.left - width - gap;
    if (x < 8 || x + width > innerWidth - 8) x = preferRight ? primary.left - width - gap : primary.right + gap;
    const anchor = this.menuActionElement(this.submenuAction?.key)?.getBoundingClientRect();
    const values = [
      ["--sim-submenu-left", clamp(x, 8, innerWidth - width - 8)],
      ["--sim-submenu-top", clamp(anchor?.top || primary.top, 8, innerHeight - height - 8)]
    ];
    for (const [prop, value] of values) {
      const pixel = `${Math.round(value)}px`;
      if (this.submenu.style.getPropertyValue(prop) !== pixel) this.submenu.style.setProperty(prop, pixel);
    }
    for (const child of this.submenu.querySelectorAll(".b3-menu__submenu")) {
      const rect = child.getBoundingClientRect();
      if (!rect.height || window.getComputedStyle(child).display === "none") continue;
      if (!this.childMenuPositions.has(child)) this.childMenuPositions.set(child, {
        hadClass: child.classList.contains("sim-child-positioned"),
        value: child.style.getPropertyValue("--sim-child-top"),
        priority: child.style.getPropertyPriority("--sim-child-top")
      });
      const parentTop = child.parentElement.getBoundingClientRect().top;
      const top = `${Math.round(clamp(parentTop, 8, innerHeight - rect.height - 8))}px`;
      if (!child.classList.contains("sim-child-positioned")) child.classList.add("sim-child-positioned");
      if (child.style.getPropertyValue("--sim-child-top") !== top) child.style.setProperty("--sim-child-top", top);
    }
  }
  closeMenu(focusOrb = false) {
    this.hideSyncTip();
    this.menu?.remove();
    this.menu = null;
    this.windowActions?.remove();
    this.windowActions = null;
    this.closeSubmenu();
    this.menuOpenedByHover = false;
    this.orb?.classList.remove("sim-orb--active");
    this.orb?.setAttribute("aria-expanded", "false");
    if (focusOrb) this.orb?.focus({ preventScroll: true });
  }
  invokeSource(element, anchor = this.orb.getBoundingClientRect()) {
    if (!element.isConnected) {
      showMessage("\u6B64\u5165\u53E3\u5DF2\u4E0D\u53EF\u7528\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u83DC\u5355\u3002");
      return;
    }
    const restores = [];
    for (const target of [element, ...element.querySelectorAll("svg")]) {
      const descriptor = Object.getOwnPropertyDescriptor(target, "getBoundingClientRect");
      try {
        Object.defineProperty(target, "getBoundingClientRect", { configurable: true, value: () => anchor });
        restores.push(() => {
          if (descriptor) Object.defineProperty(target, "getBoundingClientRect", descriptor);
          else delete target.getBoundingClientRect;
        });
      } catch {
      }
    }
    const restore = () => {
      restores.forEach((fn) => fn());
      this.geometryRestores.delete(restore);
    };
    this.geometryRestores.add(restore);
    try {
      element.click();
    } finally {
      requestAnimationFrame(restore);
    }
  }
  revealPageTools() {
    const element = this.findPageTools();
    if (!element) {
      showMessage("\u5F53\u524D\u9875\u9762\u6CA1\u6709\u53EF\u7528\u7684\u6587\u6863\u5DE5\u5177\u3002");
      return;
    }
    this.clearNativeTools(false);
    element.classList.add("sim-page-tools");
    this.nativeReveals.add(element);
    showMessage("\u5DF2\u663E\u793A\u539F\u751F\u9875\u9762\u5DE5\u5177\uFF1B\u70B9\u51FB\u5176\u4ED6\u4F4D\u7F6E\u6216\u6309 Esc \u6536\u8D77\u3002", 2500);
  }
  findPageTools() {
    const candidates = [...document.querySelectorAll(".layout__center .protyle:not(.fn__none) .protyle-breadcrumb")].filter((element) => !element.closest(".fn__none, [hidden]"));
    return candidates.find((element) => element.closest(".layout__wnd--active")) || candidates[0];
  }
  showDefaultPageTools() {
    const element = this.findPageTools();
    if (!element) return;
    element.classList.add("sim-page-tools");
    this.nativeReveals.add(element);
    this.defaultPageTools.add(element);
  }
  syncDefaultPageTools() {
    if (!this.active) return;
    if ([...this.nativeReveals].some((element) => !this.defaultPageTools.has(element))) return;
    const current = this.findPageTools();
    const defaults = [...this.defaultPageTools].filter((element) => element.isConnected);
    if (current === (defaults.length === 1 ? defaults[0] : null) && defaults.length === this.defaultPageTools.size) return;
    this.clearNativeTools(false);
    this.showDefaultPageTools();
  }
  revealToolbar() {
    if (document.body.classList.contains("sim-keep-topbar")) return;
    const element = document.getElementById("toolbar");
    if (!element) {
      this.leave();
      return;
    }
    this.clearNativeTools(false);
    element.classList.add("sim-native-tools");
    this.nativeReveals.add(element);
    showMessage("\u5DF2\u4E34\u65F6\u663E\u793A\u539F\u751F\u5DE5\u5177\u680F\uFF1B\u70B9\u51FB\u5176\u4ED6\u4F4D\u7F6E\u6216\u6309 Esc \u6536\u8D77\u3002", 2500);
  }
  clearNativeTools(preservePageTools = true) {
    for (const element of this.nativeReveals) {
      if (preservePageTools && this.defaultPageTools.has(element)) continue;
      element.classList.remove("sim-page-tools", "sim-native-tools");
      this.defaultPageTools.delete(element);
    }
    this.nativeReveals = new Set(preservePageTools ? [...this.nativeReveals].filter((element) => this.defaultPageTools.has(element)) : []);
  }
  leave() {
    const wasActive = this.active;
    this.active = false;
    if (this.resourceEnterFrame != null) window.cancelAnimationFrame(this.resourceEnterFrame);
    this.resourceEnterFrame = null;
    this.pendingResourceTabs?.clear();
    this.stopMergedTabs();
    this.observer?.disconnect();
    this.observer = null;
    this.windowStateObserver?.disconnect();
    this.windowStateObserver = null;
    clearTimeout(this.refreshTimer);
    this.refreshTimer = null;
    for (const cleanup of this.cleanups || []) {
      try {
        cleanup();
      } catch (error) {
        console.warn(error);
      }
    }
    this.cleanups = [];
    this.closeMenu();
    this.clearNativeTools(false);
    this.defaultPageTools.clear();
    for (const restore of this.geometryRestores) restore();
    for (const row of this.markedRows) row.classList.remove("sim-layout-row");
    this.markedRows.clear();
    this.orb?.remove();
    this.orb = null;
    this.dragRegion?.remove();
    this.dragRegion = null;
    this.windowActions?.remove();
    this.windowActions = null;
    this.styleElement?.remove();
    this.styleElement = null;
    this.drag = null;
    this.suppressClick = false;
    document.body.classList.remove("sim-active", "sim-keep-topbar", "sim-window-strip");
    this.updateTopButton();
    if (wasActive) {
      document.getElementById("toolbar")?.getBoundingClientRect();
      window.dispatchEvent(new window.Event("resize"));
    }
  }
  onunload() {
    this.disposed = true;
    if (this.topButtonIconFrame != null) window.cancelAnimationFrame(this.topButtonIconFrame);
    this.topButtonIconFrame = null;
    this.resourceObserver?.disconnect();
    this.resourceObserver = null;
    if (this.resourceEnterFrame != null) window.cancelAnimationFrame(this.resourceEnterFrame);
    this.resourceEnterFrame = null;
    this.leave();
    if (this.setting?.dialog?.element?.isConnected) this.setting.dialog.destroy();
    this.uiStyle?.remove();
    this.uiStyle = null;
    this.topButton?.remove();
    this.topButton = null;
  }
};
